# AI Resume Builder

Responsive resume builder with live preview, built with HTML, CSS, Bootstrap 5 and vanilla JavaScript. Enter personal info, experience, education and skills, then save in-browser, print, or export a PDF with html2pdf.js. Includes sample data and one-click clear.

## Features
- Live resume preview that updates as you type
- Sections: personal info, summary, two experience entries, education, skills
- Save and auto-restore your resume with browser localStorage
- Download as PDF (html2pdf.js) or print with a print-friendly layout
- Load sample data and clear the form in one click
- HTML-escaped output for safe rendering of user text

## Tech Stack
HTML5, CSS3, Bootstrap 5.3, JavaScript (ES6), html2pdf.js

## Run Locally
Clone the repo and open `index.html` in your browser. No build step needed. An internet connection is required for the Bootstrap and html2pdf CDN files.

## Roadmap
- AI-generated summary and bullet suggestions
- More experience entries and resume templates

## License
MIT
