const form = document.getElementById("resumeForm");
const statusMessage = document.getElementById("statusMessage");

const sampleData = {
    fullName: "Konappagari Venkatesh",
    title: "Frontend Developer",
    email: "your-email@example.com",
    phone: "1234567890",
    location: "Chittoor",
    website: "portfolio.com",
    summary: "Motivated developer interested in web development.",
    exp1Company: "ABC Company",
    exp1Role: "Web Development Intern",
    exp1Period: "2025 - 2026",
    exp1Description: "Worked on front-end web development projects.",
    exp2Company: "",
    exp2Role: "",
    exp2Period: "",
    exp2Description: "",
    school: "Your College",
    degree: "B.Tech",
    educationPeriod: "2022 - 2026",
    skills: "HTML, CSS, JavaScript, Bootstrap"
};

function updateStatus(message) {
    statusMessage.textContent = message;
}

function escapeHTML(value = "") {
    return value.replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

function readForm() {
    const data = {};
    form.querySelectorAll("input, textarea").forEach(field => {
        data[field.id] = field.value.trim();
    });
    return data;
}

function fillForm(data) {
    Object.entries(data).forEach(([id, value]) => {
        const field = document.getElementById(id);
        if (field) field.value = value;
    });
}

function renderResume() {
    const data = readForm();

    const fields = {
        previewName: data.fullName || "Your Name",
        previewTitle: data.title || "Professional Title",
        previewEmail: data.email || "",
        previewPhone: data.phone || "",
        previewLocation: data.location || "",
        previewWebsite: data.website || "",
        previewSummary: data.summary || ""
    };

    Object.entries(fields).forEach(([id, value]) => {
        document.getElementById(id).textContent = value;
    });

    const experiences = [
        {
            company: data.exp1Company,
            role: data.exp1Role,
            period: data.exp1Period,
            description: data.exp1Description
        },
        {
            company: data.exp2Company,
            role: data.exp2Role,
            period: data.exp2Period,
            description: data.exp2Description
        }
    ];

    document.getElementById("previewExperience").innerHTML =
        experiences
            .filter(item => item.company || item.role || item.description)
            .map(item => `
                <div class="mb-3">
                    <h5>${escapeHTML(item.role)}</h5>
                    <p>${escapeHTML([item.company, item.period]
                        .filter(Boolean).join(" | "))}</p>
                    <p>${escapeHTML(item.description)}</p>
                </div>
            `).join("");

    document.getElementById("previewEducation").textContent =
        [data.degree, data.school, data.educationPeriod]
            .filter(Boolean).join(" | ");

    document.getElementById("previewSkills").textContent = data.skills || "";
}

form.addEventListener("input", renderResume);

document.getElementById("loadSampleBtn").addEventListener("click", () => {
    fillForm(sampleData);
    renderResume();
    updateStatus("Sample resume loaded.");
});

document.getElementById("saveBtn").addEventListener("click", () => {
    try {
        localStorage.setItem("resumeData", JSON.stringify(readForm()));
        updateStatus("Resume saved in this browser.");
    } catch {
        updateStatus("Could not save: browser storage is unavailable.");
    }
});

document.getElementById("clearBtn").addEventListener("click", () => {
    form.reset();
    renderResume();
    updateStatus("Form cleared.");
});

document.getElementById("printBtn").addEventListener("click", () => {
    window.print();
});

document.getElementById("downloadPdfBtn").addEventListener("click", () => {
    if (typeof html2pdf === "undefined") {
        updateStatus("PDF library failed to load. Check your internet connection.");
        return;
    }
    const preview = document.getElementById("resumePreview");
    html2pdf().set({
        margin: 10,
        filename: "my-resume.pdf",
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" }
    }).from(preview).save();
    updateStatus("Preparing your PDF...");
});

// Restore saved resume on page load
try {
    const savedData = localStorage.getItem("resumeData");
    if (savedData) {
        fillForm(JSON.parse(savedData));
        updateStatus("Loaded your saved resume.");
    }
} catch {
    // Storage unavailable or data corrupted; start with an empty form
}
renderResume();
